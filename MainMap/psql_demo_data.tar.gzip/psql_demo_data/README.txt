demo data extract from the following sql ommands:
    select * from ptt_contents where content like '%流感%' or content like '%A型肝炎%' or content like '%登革熱%' or content like '%腸病毒%';

dumping commands:
    pg_dump -v -t ptt_contents_tmp -Fd ptt -j 10 -f ~/psql_demo_data

full restore commands:
    sudo -u postgres createuser --interactive # 建立user
    createdb -T template0 ptt
    pg_restore -v -j 5 -d ptt psql_demo_data
